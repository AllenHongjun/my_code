#include <stdlib.h>
#include "AS3/AS3.h"


int main() {
    AS3_GoAsync();
}